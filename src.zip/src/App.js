import React, { useState } from 'react';
import ClassesList from './components/ClassesList';
import BookingForm from './components/BookingForm';
import BookingsList from './components/BookingsList';

function App() {
  const [selectedClass, setSelectedClass] = useState(null);

  return (
    <div style={{ padding: '20px' }}>
      <h1 style={{ textAlign: 'center' }}>Fitness Studio Booking</h1>
      <ClassesList onSelectClass={setSelectedClass} />
      <BookingForm selectedClass={selectedClass} onSuccess={() => setSelectedClass(null)} />
      <hr />
      <BookingsList />
    </div>
  );
}

export default App;

import React, { useState } from 'react';
import { postBooking } from '../api';  // <-- Import postBooking API function

const BookingForm = ({ selectedClass, onSuccess }) => {
  const [clientName, setClientName] = useState('');
  const [clientEmail, setClientEmail] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (!selectedClass) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!clientName || !clientEmail) {
      setError('Please fill all fields');
      return;
    }
    setLoading(true);
    try {
      await postBooking({
        class_id: selectedClass.id,
        client_name: clientName,
        client_email: clientEmail,
      });
      setClientName('');
      setClientEmail('');
      onSuccess();
      alert('Booking successful!');
    } catch (err) {
      setError(err.response?.data?.error || 'Booking failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container my-4 p-4 border rounded shadow-sm bg-light">
      <h3 className="mb-3">Book Class: {selectedClass.name}</h3>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <input
            type="text"
            placeholder="Your Name"
            value={clientName}
            onChange={e => setClientName(e.target.value)}
            className="form-control"
          />
        </div>
        <div className="mb-3">
          <input
            type="email"
            placeholder="Your Email"
            value={clientEmail}
            onChange={e => setClientEmail(e.target.value)}
            className="form-control"
          />
        </div>
        <button disabled={loading} type="submit" className="btn btn-primary">
          {loading ? 'Booking...' : 'Book'}
        </button>
      </form>
      {error && <p className="text-danger mt-2">{error}</p>}
    </div>
  );
};

export default BookingForm;

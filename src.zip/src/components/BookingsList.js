import React, { useState } from 'react';
import { fetchBookings } from '../api';  // <-- Import fetchBookings API function
import moment from 'moment-timezone';

const BookingsList = () => {
  const [email, setEmail] = useState('');
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState('');

  const handleSearch = async () => {
    setError('');
    setBookings([]);
    if (!email) {
      setError('Enter an email to search');
      return;
    }
    try {
      const res = await fetchBookings(email);
      setBookings(res.data);
    } catch {
      setError('Failed to fetch bookings');
    }
  };

  return (
    <div className="container my-4 p-4 border rounded shadow-sm bg-light">
      <h2 className="mb-3 text-center text-primary">Your Bookings</h2>
      <div className="input-group mb-3">
        <input
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          className="form-control"
        />
        <button onClick={handleSearch} className="btn btn-primary">
          Search
        </button>
      </div>
      {error && <p className="text-danger">{error}</p>}
      <ul className="list-group">
        {bookings.map(b => (
          <li key={b.id} className="list-group-item d-flex justify-content-between align-items-center">
            <div>
              <strong>{b.client_name}</strong> booked <b>{b.fitness_class.name}</b> by {b.fitness_class.instructor}
            </div>
            <small className="text-muted">
              {moment(b.booked_at).format('YYYY-MM-DD HH:mm')}
            </small>
          </li>
        ))}
      </ul>
      {bookings.length === 0 && !error && <p className="text-center fst-italic text-muted mt-3">No bookings found</p>}
    </div>
  );
};

export default BookingsList;

from django.db import models
from django.utils.timezone import make_aware
import datetime
import pytz

IST = pytz.timezone('Asia/Kolkata')

class FitnessClass(models.Model):
    name = models.CharField(max_length=100)
    datetime_ist = models.DateTimeField()  # store in IST
    instructor = models.CharField(max_length=100)
    slots = models.PositiveIntegerField(default=0)

    def save(self, *args, **kwargs):
        # Ensure datetime_ist is timezone aware in IST
        if self.datetime_ist and self.datetime_ist.tzinfo is None:
            self.datetime_ist = IST.localize(self.datetime_ist)
        super().save(*args, **kwargs)

    def get_datetime_in_timezone(self, tz_str):
        tz = pytz.timezone(tz_str)
        return self.datetime_ist.astimezone(tz)

    def __str__(self):
        return f"{self.name} by {self.instructor} on {self.datetime_ist}"

class Booking(models.Model):
    fitness_class = models.ForeignKey(FitnessClass, on_delete=models.CASCADE, related_name='bookings')
    client_name = models.CharField(max_length=100)
    client_email = models.EmailField()

    booked_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.client_name} booked {self.fitness_class.name}"

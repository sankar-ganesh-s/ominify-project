from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import FitnessClass, Booking
from .serializers import FitnessClassSerializer, BookingSerializer, BookingCreateSerializer
from django.shortcuts import get_object_or_404
from django.db import transaction

@api_view(['GET'])
def get_classes(request):
    classes = FitnessClass.objects.all()
    serializer = FitnessClassSerializer(classes, many=True)
    return Response(serializer.data)

@api_view(['POST'])
def book_class(request):
    serializer = BookingCreateSerializer(data=request.data)
    if serializer.is_valid():
        class_id = serializer.validated_data['class_id']
        client_name = serializer.validated_data['client_name']
        client_email = serializer.validated_data['client_email']

        fitness_class = get_object_or_404(FitnessClass, id=class_id)

        if fitness_class.slots <= 0:
            return Response({'error': 'No slots available'}, status=status.HTTP_400_BAD_REQUEST)

        # Transaction to avoid race conditions
        with transaction.atomic():
            fitness_class = FitnessClass.objects.select_for_update().get(id=class_id)
            if fitness_class.slots <= 0:
                return Response({'error': 'No slots available'}, status=status.HTTP_400_BAD_REQUEST)
            fitness_class.slots -= 1
            fitness_class.save()

            booking = Booking.objects.create(
                fitness_class=fitness_class,
                client_name=client_name,
                client_email=client_email,
            )
            booking_serializer = BookingSerializer(booking)
            return Response(booking_serializer.data, status=status.HTTP_201_CREATED)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
def get_bookings(request):
    email = request.query_params.get('email')
    if not email:
        return Response({'error': 'Email query param required'}, status=status.HTTP_400_BAD_REQUEST)

    # Add select_related to fetch related FitnessClass info in the same query
    bookings = Booking.objects.filter(client_email=email).select_related('fitness_class')
    serializer = BookingSerializer(bookings, many=True)
    return Response(serializer.data)

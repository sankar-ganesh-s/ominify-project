import React, { useEffect, useState } from 'react';
import { fetchClasses } from '../api';
import moment from 'moment-timezone';

const ClassesList = ({ onSelectClass }) => {
  const [classes, setClasses] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchClasses()
      .then(res => {
        if (Array.isArray(res.data)) {
          setClasses(res.data);
          setError(null);
        } else {
          setClasses([]);
          setError('Received invalid classes data');
        }
      })
      .catch(() => setError('Failed to load classes'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="text-center my-5">Loading classes...</div>;
  if (error) return <div className="alert alert-danger my-3">{error}</div>;

  return (
    <div className="container my-4">
      <h2 className="mb-4 text-center text-primary">Available Classes</h2>
      {classes.length === 0 ? (
        <p className="text-center fst-italic text-muted">No classes available</p>
      ) : (
        <div className="row g-4">
          {classes.map(c => (
            <div key={c.id} className="col-md-4">
              <div
                className={`card h-100 shadow-sm ${c.slots === 0 ? 'border-danger' : ''}`}
                style={{ cursor: c.slots > 0 ? 'pointer' : 'not-allowed', transition: 'transform 0.2s' }}
                onClick={() => c.slots > 0 && onSelectClass(c)}
                onMouseEnter={e => {
                  if (c.slots > 0) e.currentTarget.style.transform = 'scale(1.03)';
                }}
                onMouseLeave={e => {
                  e.currentTarget.style.transform = 'scale(1)';
                }}
              >
                <div className="card-header bg-primary text-white text-center fw-bold fs-5">
                  {c.name}
                </div>
                <div className="card-body d-flex flex-column">
                  <p className="card-text mb-2">
                    <i className="bi bi-clock me-2"></i>
                    <strong>Time:</strong>{' '}
                    {moment.tz(c.datetime_ist, 'Asia/Kolkata').format('YYYY-MM-DD HH:mm')} IST
                  </p>
                  <p className="card-text mb-2">
                    <i className="bi bi-person-fill me-2"></i>
                    <strong>Instructor:</strong> {c.instructor}
                  </p>
                  <p className="mb-3">
                    <span className={`badge ${c.slots > 0 ? 'bg-success' : 'bg-danger'} fs-6 fw-semibold`}>
                      Slots Available: {c.slots}
                    </span>
                  </p>
                  <button
                    className={`btn mt-auto ${c.slots > 0 ? 'btn-primary' : 'btn-secondary'} fw-semibold`}
                    disabled={c.slots === 0}
                    onClick={e => {
                      e.stopPropagation();
                      onSelectClass(c);
                    }}
                  >
                    {c.slots > 0 ? 'Book Now' : 'Full'}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ClassesList;

from django.apps import AppConfig


class ClassesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'classes_app'

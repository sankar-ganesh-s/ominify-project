from classes_app.models import FitnessClass
from django.utils import timezone
from datetime import timedelta

def run():
    FitnessClass.objects.all().delete()
    FitnessClass.objects.create(
        name='Yoga',
        datetime_ist=timezone.now() + timedelta(days=1),
        instructor='Alice',
        slots=10
    )
    FitnessClass.objects.create(
        name='Zumba',
        datetime_ist=timezone.now() + timedelta(days=2),
        instructor='Bob',
        slots=5
    )
    FitnessClass.objects.create(
        name='HIIT',
        datetime_ist=timezone.now() + timedelta(days=3),
        instructor='Charlie',
        slots=8
    )
    print("Seed data added.")

# Call the run function when this script is executed
run()

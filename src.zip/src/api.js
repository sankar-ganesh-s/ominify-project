import axios from 'axios';

const API_BASE = 'http://127.0.0.1:8000/api';

export const fetchClasses = () => axios.get(`${API_BASE}/classes/`);

export const postBooking = (data) => axios.post(`${API_BASE}/book/`, data);

export const fetchBookings = (email) => axios.get(`${API_BASE}/bookings/`, { params: { email }});
